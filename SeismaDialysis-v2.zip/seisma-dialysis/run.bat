@echo off
cd %~dp0backend
if not exist node_modules (
  echo Installing dependencies (first run only)...
  call npm install
)
echo Starting SeismaDialysis...
echo Open http://localhost:3000 in your browser once you see "API running" below.
call npm start
pause
