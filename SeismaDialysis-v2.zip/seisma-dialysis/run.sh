#!/bin/bash
# Double-click (or run: ./run.sh) to install dependencies (first run only)
# and start the SeismaDialysis server.
cd "$(dirname "$0")/backend"
if [ ! -d "node_modules" ]; then
  echo "Installing dependencies (first run only)..."
  npm install
fi
echo "Starting SeismaDialysis..."
echo "Open http://localhost:3000 in your browser once you see 'API running' below."
npm start
