// store.js
// A minimal, dependency-free "database" that saves everything to one JSON
// file on disk (data.json). No native modules, no experimental flags —
// this runs the same way on every Node version and every OS.
//
// If you outgrow this (multiple concurrent writers, huge datasets), the
// swap-in replacement is a real database like SQLite or Postgres — but for
// a single dialysis unit tracking one event at a time, a JSON file is
// simple, inspectable (you can open data.json in a text editor), and has
// nothing to misconfigure.

const fs = require('fs');
const path = require('path');

const DATA_PATH = path.join(__dirname, 'data.json');

const EMPTY_STATE = {
  event: null,       // { id, started_at, ended_at }
  checklist: [],      // [{ step_key, checked }]
  patients: [],        // [{ id, label, on_machine, clamped, disconnected, evacuated, created_at }]
  log: [],              // [{ id, at, message }]
  nextPatientId: 1,
  nextLogId: 1,
  nextEventId: 1,
};

function load() {
  if (!fs.existsSync(DATA_PATH)) {
    save(EMPTY_STATE);
    return { ...EMPTY_STATE };
  }
  try {
    const raw = fs.readFileSync(DATA_PATH, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('data.json was unreadable, starting fresh:', err.message);
    save(EMPTY_STATE);
    return { ...EMPTY_STATE };
  }
}

function save(state) {
  // Write to a temp file then rename — avoids a half-written data.json
  // if the process is killed mid-save.
  const tmpPath = DATA_PATH + '.tmp';
  fs.writeFileSync(tmpPath, JSON.stringify(state, null, 2));
  fs.renameSync(tmpPath, DATA_PATH);
}

module.exports = { load, save, EMPTY_STATE };
