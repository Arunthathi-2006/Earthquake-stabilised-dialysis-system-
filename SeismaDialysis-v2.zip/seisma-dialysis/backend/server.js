const express = require('express');
const cors = require('cors');
const path = require('path');
const { load, save } = require('./store');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// Must match the step counts in frontend/script.js (steps1/steps2/steps3)
const PHASE_STEP_COUNTS = { p1: 4, p2: 6, p3: 6 };

function nowISO() {
  return new Date().toISOString();
}

function addLog(state, message) {
  state.log.push({ id: state.nextLogId++, at: nowISO(), message });
  // keep the log from growing forever in a long-running process
  if (state.log.length > 500) state.log = state.log.slice(-500);
}

// ---- Health check (useful for confirming the server is actually up) ----
app.get('/api/health', (req, res) => {
  res.json({ ok: true, time: nowISO() });
});

// ---- Event lifecycle -------------------------------------------------

app.get('/api/event/current', (req, res) => {
  const state = load();
  res.json({ event: state.event });
});

app.post('/api/event/start', (req, res) => {
  const state = load();
  if (state.event) {
    return res.json({ event: state.event }); // already active, don't double-start
  }
  state.event = { id: state.nextEventId++, started_at: nowISO(), ended_at: null };
  state.checklist = [];
  for (const [prefix, count] of Object.entries(PHASE_STEP_COUNTS)) {
    for (let i = 0; i < count; i++) {
      state.checklist.push({ step_key: `${prefix}-${i}`, checked: false });
    }
  }
  state.patients = [];
  addLog(state, 'Seismic event declared. Protocol started.');
  save(state);
  res.json({ event: state.event });
});

app.post('/api/event/reset', (req, res) => {
  const state = load();
  if (state.event) {
    addLog(state, 'Event reset / closed.');
  }
  state.event = null;
  state.checklist = [];
  state.patients = [];
  save(state);
  res.json({ ok: true });
});

// ---- Checklist ---------------------------------------------------------

app.get('/api/checklist', (req, res) => {
  const state = load();
  res.json({ items: state.checklist });
});

app.post('/api/checklist/:stepKey/toggle', (req, res) => {
  const state = load();
  if (!state.event) return res.status(400).json({ error: 'No active event' });
  const item = state.checklist.find(i => i.step_key === req.params.stepKey);
  if (!item) return res.status(404).json({ error: 'Step not found' });
  item.checked = !item.checked;
  addLog(state, `${item.checked ? 'Checked' : 'Unchecked'} step ${item.step_key}`);
  save(state);
  res.json({ step_key: item.step_key, checked: item.checked });
});

// ---- Patients ------------------------------------------------------------
// `label` is meant to be a de-identified reference (chair/bed number),
// not a full patient name — see README.

app.get('/api/patients', (req, res) => {
  const state = load();
  res.json({ patients: state.patients });
});

app.post('/api/patients', (req, res) => {
  const state = load();
  if (!state.event) return res.status(400).json({ error: 'No active event' });
  const label = (req.body.label || '').trim();
  if (!label) return res.status(400).json({ error: 'label is required' });

  const patient = {
    id: state.nextPatientId++,
    label,
    on_machine: true,
    clamped: false,
    disconnected: false,
    evacuated: false,
    created_at: nowISO(),
  };
  state.patients.push(patient);
  addLog(state, `Added patient "${label}" to roster.`);
  save(state);
  res.json({ patient });
});

app.post('/api/patients/bulk', (req, res) => {
  const state = load();
  if (!state.event) return res.status(400).json({ error: 'No active event' });
  const labels = Array.isArray(req.body.labels) ? req.body.labels : [];

  let count = 0;
  for (const raw of labels) {
    const label = (raw || '').trim();
    if (!label) continue;
    state.patients.push({
      id: state.nextPatientId++,
      label,
      on_machine: true,
      clamped: false,
      disconnected: false,
      evacuated: false,
      created_at: nowISO(),
    });
    count++;
  }
  addLog(state, `Bulk-imported ${count} patient(s) into roster.`);
  save(state);
  res.json({ imported: count, patients: state.patients });
});

app.patch('/api/patients/:id', (req, res) => {
  const state = load();
  const id = Number(req.params.id);
  const patient = state.patients.find(p => p.id === id);
  if (!patient) return res.status(404).json({ error: 'Patient not found' });

  const fields = ['on_machine', 'clamped', 'disconnected', 'evacuated'];
  let changedField = null;
  for (const f of fields) {
    if (f in req.body) {
      patient[f] = !!req.body[f];
      changedField = f;
    }
  }
  if (changedField) {
    addLog(state, `${patient.label}: ${changedField.replace('_', ' ')} → ${patient[changedField] ? 'yes' : 'no'}`);
  }
  save(state);
  res.json({ patient });
});

app.delete('/api/patients/:id', (req, res) => {
  const state = load();
  const id = Number(req.params.id);
  const patient = state.patients.find(p => p.id === id);
  state.patients = state.patients.filter(p => p.id !== id);
  if (patient) addLog(state, `Removed "${patient.label}" from roster.`);
  save(state);
  res.json({ ok: true });
});

// ---- Activity log --------------------------------------------------------

app.get('/api/log', (req, res) => {
  const state = load();
  res.json({ log: state.log });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`SeismaDialysis API running on http://localhost:${PORT}`);
  console.log(`Data is stored in ${path.join(__dirname, 'data.json')}`);
});
