# SeismaDialysis

A protocol and patient-tracking tool for dialysis units to use during and
immediately after an earthquake.

- **Frontend** — plain HTML/CSS/JS (`frontend/`), no framework or build step
- **Backend** — Node.js + Express REST API (`backend/server.js`)
- **Storage** — a single JSON file (`backend/data.json`), written and read
  through `backend/store.js`

## What's new in this version

- **No experimental flags, no native builds.** Earlier drafts used Node's
  built-in SQLite module, which needs `--experimental-sqlite` and isn't
  available on every Node version — this was the most likely cause if you
  saw `server.js` fail to start before. Storage is now a plain JSON file,
  which works identically on any Node version and OS, and needs nothing
  installed beyond `express` and `cors`.
- **Progress bars** for each protocol phase, updating live as steps are checked.
- **Activity log** — every action (event start, step checked, patient added/
  updated/removed, reset) is timestamped automatically, visible in the app,
  and stored so it survives a refresh.
- **Export Incident Report** — one click opens a clean, printable summary of
  the checklist, roster, and full activity log, for an after-action review
  or facility reporting.
- **Live seismograph line** in the header — flat at standby, active/jagged
  while an event is running, as a glanceable status indicator.

## Running it

```bash
cd backend
npm install
npm start
```

Then open `http://localhost:3000`. Express serves both the frontend files
and the API from one process — nothing else to configure.

Windows users: double-click `run.bat` in the project root (after running
`npm install` once inside `backend/`). Mac/Linux users: `./run.sh`.

## Where your data lives

Everything is stored in `backend/data.json` — open it in any text editor to
see exactly what the app has saved. Deleting that file (with the server
stopped) resets the app to a blank slate.

## API

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | Confirm the server is running |
| GET | `/api/event/current` | Get the active event, if any |
| POST | `/api/event/start` | Start a new event, seed the checklist |
| POST | `/api/event/reset` | Close the event, clear checklist + roster |
| GET | `/api/checklist` | Get checklist items + checked state |
| POST | `/api/checklist/:stepKey/toggle` | Toggle one checklist item |
| GET | `/api/patients` | List patients for the current event |
| POST | `/api/patients` | Add one patient (`{ "label": "Chair 4" }`) |
| POST | `/api/patients/bulk` | Bulk add (`{ "labels": ["Chair 1","Chair 2"] }`) |
| PATCH | `/api/patients/:id` | Update status flags |
| DELETE | `/api/patients/:id` | Remove a patient row |
| GET | `/api/log` | Get the timestamped activity log |

## Important limitations — read before treating this as more than a prototype

- **Not HIPAA-compliant infrastructure.** No authentication, no encryption
  at rest, no access control — `data.json` is plain text on disk. The
  `label` field is meant to be a chair/bed number, not a patient's legal
  name, for exactly this reason.
- **The protocol content is a general best-practice checklist**, not
  sourced from a specific regulatory body or your facility's official
  policy. Check it against your facility's written emergency plan before
  relying on it, and edit `steps1`/`steps2`/`steps3` in `frontend/script.js`
  to match (keep `PHASE_STEP_COUNTS` in `server.js` and `PHASE_TOTALS` in
  `script.js` in sync with however many steps you end up with per phase).
- **Single event, single unit.** It assumes one dialysis unit tracking one
  event at a time — not built for a multi-facility network.
- **No live multi-device sync.** Two people editing from two different
  devices at the same time will have "last write wins" behavior — each
  device shows its own view until it next reloads or takes an action.

## Possible next steps for this project

- Add authentication (even a simple shared unit passcode).
- Add WebSockets for live sync across every device in the unit.
- Move from a JSON file to a real database if you outgrow a single unit.
- Get the protocol content reviewed against your national renal nursing
  body's emergency-preparedness guidance and cite the source in-app.
