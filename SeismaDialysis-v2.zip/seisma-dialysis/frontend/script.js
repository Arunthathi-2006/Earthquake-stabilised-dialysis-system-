const steps1 = [
  {t:"Call out \"EARTHQUAKE — HOLD\" to alert the room", d:"Verbal alert first. Staff should stop walking and stay near their assigned chair.", tag:"crit"},
  {t:"Stay at your assigned patient's side", d:"Do not run to shut off machines across the room while the floor is moving — falls during shaking are a bigger risk than the machine itself.", tag:"crit"},
  {t:"Shield the patient and the vascular access site", d:"Use your body or a pillow to protect the access arm/site from falling objects or the chair tipping.", tag:"crit"},
  {t:"Do NOT attempt to disconnect while the floor is still moving", d:"Wait for shaking to stop before touching lines — sudden movement during active shaking raises the risk of a line pulling loose uncontrolled.", tag:"wait"},
];

const steps2 = [
  {t:"Stop the blood pump", d:"Silence/stop the pump on each affected machine before anything else.", tag:"crit"},
  {t:"Clamp the arterial and venous lines", d:"Clamp both lines at the patient end to prevent blood loss or air entry if a line has been compromised.", tag:"crit"},
  {t:"Assess whether it's safe to return blood", d:"If the machine is undamaged, power is stable, and the connection is intact, blood may be returned per your unit's normal end-of-treatment procedure. If in doubt, disconnect and do not return blood.", tag:"wait"},
  {t:"Disconnect the patient from the machine", d:"Cap or clamp all access points once blood is dealt with. Confirm hemostasis at the access site.", tag:"crit"},
  {t:"Check the patient for injury before moving them", d:"Look for cuts from broken glass/equipment, check the access site is intact, ask about pain or dizziness.", tag:"crit"},
  {t:"Move ambulatory patients away from windows and heavy equipment", d:"Use planned evacuation routes. Non-ambulatory patients stay put with a staff member until transport is arranged.", tag:"wait"},
];

const steps3 = [
  {t:"Check for gas odor, water leaks, and downed electrical lines", d:"Do not re-enter or continue operating equipment in a room with a suspected gas leak — evacuate and shut the main valve if trained and safe to do so.", tag:"crit"},
  {t:"Check the water treatment/RO system and dialysate lines for leaks or damage", d:"Shut off water supply to the unit if lines are cracked or leaking to prevent flooding and RO system damage.", tag:"crit"},
  {t:"Account for every patient and staff member in the unit", d:"Use the Patient Roster below — nobody leaves the count until they're marked evacuated.", tag:"crit"},
  {t:"Check on patients currently off-machine but in the facility", d:"Waiting-room and pre-treatment patients need the same injury check and accounting.", tag:"wait"},
  {t:"Contact facility emergency coordinator / activate emergency plan", d:"Report headcount, injuries, and equipment status per your facility's chain of communication.", tag:"crit"},
  {t:"Do not resume treatment until equipment and water systems are cleared", d:"Wait for biomedical/engineering sign-off on machines and water system before restarting any patient.", tag:"wait"},
];

function renderPhase(containerId, list, prefix){
  const el = document.getElementById(containerId);
  el.innerHTML = list.map((s,i)=>`
    <div class="step" data-key="${prefix}-${i}">
      <button class="step-check" data-key="${prefix}-${i}"></button>
      <div class="step-num">${prefix==='p1'?'A':prefix==='p2'?'B':'C'}${i+1}</div>
      <div class="step-body">
        <div class="step-title">${s.t}<span class="tag ${s.tag}">${s.tag==='crit'?'Critical':'Judgment call'}</span></div>
        <div class="step-detail">${s.d}</div>
      </div>
    </div>`).join('');
}
renderPhase('phase1', steps1, 'p1');
renderPhase('phase2', steps2, 'p2');
renderPhase('phase3', steps3, 'p3');

// ---- API helper ----
async function api(path, opts={}){
  const res = await fetch(path, { headers:{'Content-Type':'application/json'}, ...opts });
  if(!res.ok){
    const body = await res.json().catch(()=>({}));
    throw new Error(body.error || `Request failed: ${path}`);
  }
  return res.json();
}

// ---- Trigger / timer state (declared first so the seismograph below can read it) ----
let active = false, startTime = null, timerInterval = null;
const triggerBtn = document.getElementById('triggerBtn');
const resetBtn = document.getElementById('resetBtn');
const reportBtn = document.getElementById('reportBtn');
const statusPill = document.getElementById('statusPill');
const protocolSection = document.getElementById('protocolSection');
const progressRow = document.getElementById('progressRow');
const timerEl = document.getElementById('timer');

// ---- Seismograph (calm flat line at standby, jagged trace when active) ----
const seismoSvg = document.getElementById('seismograph');
const seismoLine = document.getElementById('seismoLine');
const SEISMO_POINTS = 40;
let seismoValues = new Array(SEISMO_POINTS).fill(24);
let seismoRAF = null;

function seismoStep(){
  const jitter = active ? (Math.random()-0.5) * 34 : (Math.random()-0.5) * 2;
  seismoValues.shift();
  seismoValues.push(24 + jitter);
  const w = 220, h = 48;
  const pts = seismoValues.map((v,i)=> `${(i/(SEISMO_POINTS-1))*w},${Math.max(2,Math.min(h-2,v))}`).join(' ');
  seismoLine.setAttribute('points', pts);
  seismoRAF = setTimeout(seismoStep, active ? 90 : 220);
}
seismoStep();

function fmt(ms){
  const s = Math.floor(ms/1000);
  const m = Math.floor(s/60);
  const ss = String(s%60).padStart(2,'0');
  return `T+${m}:${ss}`;
}

function goActive(startedAtISO){
  active = true;
  startTime = new Date(startedAtISO).getTime();
  statusPill.textContent = 'Event Active';
  statusPill.className = 'status-pill active';
  seismoSvg.classList.add('active');
  triggerBtn.textContent = 'Event In Progress';
  triggerBtn.classList.add('is-active');
  protocolSection.classList.add('show');
  progressRow.style.display = 'grid';
  reportBtn.disabled = false;
  clearInterval(timerInterval);
  timerInterval = setInterval(()=>{ timerEl.textContent = fmt(Date.now()-startTime); }, 1000);
  timerEl.textContent = fmt(Date.now()-startTime);
}

function goStandby(){
  active = false;
  clearInterval(timerInterval);
  statusPill.textContent = 'Standby';
  statusPill.className = 'status-pill calm';
  seismoSvg.classList.remove('active');
  triggerBtn.textContent = 'Declare Seismic Event — Start Protocol';
  triggerBtn.classList.remove('is-active');
  protocolSection.classList.remove('show');
  progressRow.style.display = 'none';
  reportBtn.disabled = true;
  timerEl.textContent = '—';
  document.querySelectorAll('.step-check').forEach(b=>b.classList.remove('checked'));
  document.querySelectorAll('.step').forEach(s=>s.classList.remove('done'));
}

triggerBtn.addEventListener('click', async ()=>{
  if(active) return;
  try{
    const { event } = await api('/api/event/start', { method:'POST' });
    goActive(event.started_at);
    await loadChecklistState();
    await loadPatients();
    await loadLog();
    window.scrollTo({top: protocolSection.offsetTop - 20, behavior:'smooth'});
  }catch(err){ alert(err.message); }
});

resetBtn.addEventListener('click', async ()=>{
  try{
    await api('/api/event/reset', { method:'POST' });
    goStandby();
    patients = [];
    logEntries = [];
    renderRoster();
    renderLog();
  }catch(err){ alert(err.message); }
});

// ---- Checklist + progress bars ----
const PHASE_TOTALS = { p1: 4, p2: 6, p3: 6 };

function updateProgress(){
  const counts = { p1:0, p2:0, p3:0 };
  document.querySelectorAll('.step-check.checked').forEach(b=>{
    const prefix = b.dataset.key.split('-')[0];
    if(prefix in counts) counts[prefix]++;
  });
  const map = { p1:['fillA','progA'], p2:['fillB','progB'], p3:['fillC','progC'] };
  for(const [prefix,[fillId,labelId]] of Object.entries(map)){
    const total = PHASE_TOTALS[prefix];
    const done = counts[prefix];
    document.getElementById(fillId).style.width = `${(done/total)*100}%`;
    document.getElementById(labelId).textContent = `${done}/${total}`;
  }
}

document.querySelectorAll('.step-check').forEach(btn=>{
  btn.addEventListener('click', async ()=>{
    const key = btn.dataset.key;
    try{
      const { checked } = await api(`/api/checklist/${key}/toggle`, { method:'POST' });
      btn.classList.toggle('checked', checked);
      btn.closest('.step').classList.toggle('done', checked);
      updateProgress();
      await loadLog();
    }catch(err){ alert(err.message); }
  });
});

async function loadChecklistState(){
  const { items } = await api('/api/checklist');
  items.forEach(item=>{
    const btn = document.querySelector(`.step-check[data-key="${item.step_key}"]`);
    if(!btn) return;
    btn.classList.toggle('checked', !!item.checked);
    btn.closest('.step').classList.toggle('done', !!item.checked);
  });
  updateProgress();
}

// ---- Patient roster ----
let patients = [];

function renderRosterSummary(){
  const total = patients.length;
  const evac = patients.filter(p=>p.evacuated).length;
  const disc = patients.filter(p=>p.disconnected).length;
  document.getElementById('rosterSummary').innerHTML = total===0 ? '' : `
    <span>Total: <b>${total}</b></span>
    <span>Disconnected: <b>${disc}</b></span>
    <span>Evacuated: <b>${evac}</b></span>
    <span>Remaining: <b>${total-evac}</b></span>
  `;
}

function renderRoster(){
  const list = document.getElementById('rosterList');
  if(patients.length===0){
    list.innerHTML = '<div class="empty">No patients added yet. Add each patient (by chair/bed label) who was in the unit when the event started.</div>';
  } else {
    list.innerHTML = patients.map(p=>`
      <div class="patient" data-id="${p.id}">
        <div>
          <div class="patient-name">${p.label}</div>
          <div class="patient-meta">Record #${p.id}</div>
        </div>
        <div class="patient-states">
          <button class="state-btn ${p.on_machine?'on state-onmachine':''}" data-state="on_machine" data-id="${p.id}">On machine</button>
          <button class="state-btn ${p.clamped?'on state-clamped':''}" data-state="clamped" data-id="${p.id}">Lines clamped</button>
          <button class="state-btn ${p.disconnected?'on state-disconnected':''}" data-state="disconnected" data-id="${p.id}">Disconnected</button>
          <button class="state-btn ${p.evacuated?'on state-evac':''}" data-state="evacuated" data-id="${p.id}">Evacuated</button>
          <button class="remove-p" data-id="${p.id}">Remove</button>
        </div>
      </div>`).join('');
  }
  renderRosterSummary();
  attachRosterEvents();
}

function attachRosterEvents(){
  document.querySelectorAll('.state-btn').forEach(btn=>{
    btn.onclick = async ()=>{
      const id = Number(btn.dataset.id);
      const state = btn.dataset.state;
      const p = patients.find(x=>x.id===id);
      const next = !p[state];
      try{
        const { patient } = await api(`/api/patients/${id}`, { method:'PATCH', body: JSON.stringify({ [state]: next }) });
        Object.assign(p, patient);
        renderRoster();
        await loadLog();
      }catch(err){ alert(err.message); }
    };
  });
  document.querySelectorAll('.remove-p').forEach(btn=>{
    btn.onclick = async ()=>{
      const id = Number(btn.dataset.id);
      try{
        await api(`/api/patients/${id}`, { method:'DELETE' });
        patients = patients.filter(x=>x.id!==id);
        renderRoster();
        await loadLog();
      }catch(err){ alert(err.message); }
    };
  });
}

async function loadPatients(){
  const { patients: list } = await api('/api/patients');
  patients = list;
  renderRoster();
}

// ---- Bulk import ----
const toggleBulk = document.getElementById('toggleBulk');
const bulkPanel = document.getElementById('bulkPanel');
toggleBulk.addEventListener('click', ()=>{
  bulkPanel.classList.toggle('show');
  toggleBulk.textContent = bulkPanel.classList.contains('show')
    ? '– Hide bulk import'
    : '+ Bulk import roster (paste list or upload CSV)';
});

async function importLabels(labels){
  try{
    const { patients: list } = await api('/api/patients/bulk', { method:'POST', body: JSON.stringify({ labels }) });
    patients = list;
    renderRoster();
    await loadLog();
    bulkPanel.classList.remove('show');
    toggleBulk.textContent = '+ Bulk import roster (paste list or upload CSV)';
  }catch(err){ alert(err.message); }
}

document.getElementById('importBulkBtn').addEventListener('click', ()=>{
  const text = document.getElementById('bulkText').value;
  if(!text.trim()) return;
  const lines = text.split(/\r?\n/);
  const labels = lines.map(line => line.includes(',') ? line.split(',')[0] : line).filter(l=>l.trim());
  document.getElementById('bulkText').value = '';
  importLabels(labels);
});

document.getElementById('csvFile').addEventListener('change', (e)=>{
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = (ev)=>{
    const text = ev.target.result;
    const lines = text.split(/\r?\n/);
    let startIdx = 0;
    if(lines[0] && /name|patient|chair|bed|label/i.test(lines[0])) startIdx = 1;
    const labels = lines.slice(startIdx).map(line => line.includes(',') ? line.split(',')[0] : line).filter(l=>l.trim());
    importLabels(labels);
  };
  reader.readAsText(file);
  e.target.value = '';
});

document.getElementById('addPatientBtn').addEventListener('click', addPatient);
document.getElementById('patientInput').addEventListener('keydown', e=>{ if(e.key==='Enter') addPatient(); });
async function addPatient(){
  const input = document.getElementById('patientInput');
  const label = input.value.trim();
  if(!label) return;
  try{
    const { patient } = await api('/api/patients', { method:'POST', body: JSON.stringify({ label }) });
    patients.push(patient);
    input.value='';
    renderRoster();
    await loadLog();
  }catch(err){ alert(err.message); }
}

// ---- Activity log ----
let logEntries = [];

function renderLog(){
  const el = document.getElementById('activityLog');
  if(logEntries.length === 0){
    el.innerHTML = '<div class="log-empty">Nothing logged yet — actions will appear here automatically as you work through the protocol.</div>';
    return;
  }
  el.innerHTML = logEntries.slice().reverse().map(entry => {
    const t = new Date(entry.at);
    const time = t.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit', second:'2-digit'});
    return `<div class="log-row"><span class="log-time">${time}</span><span class="log-msg">${entry.message}</span></div>`;
  }).join('');
}

async function loadLog(){
  const { log } = await api('/api/log');
  logEntries = log;
  renderLog();
}

// ---- Export incident report (printable) ----
reportBtn.addEventListener('click', ()=>{
  const checkedKeys = new Set(
    Array.from(document.querySelectorAll('.step-check.checked')).map(b=>b.dataset.key)
  );
  const phaseHtml = (list, prefix, label) => `
    <h3>${label}</h3>
    <ul>
      ${list.map((s,i)=>{
        const key = `${prefix}-${i}`;
        const done = checkedKeys.has(key);
        return `<li>[${done?'x':' '}] ${s.t}</li>`;
      }).join('')}
    </ul>`;

  const rosterHtml = patients.length === 0 ? '<p><em>No patients recorded.</em></p>' : `
    <table>
      <tr><th>Chair/Bed</th><th>On machine</th><th>Clamped</th><th>Disconnected</th><th>Evacuated</th></tr>
      ${patients.map(p=>`<tr>
        <td>${p.label}</td>
        <td>${p.on_machine?'Yes':'—'}</td>
        <td>${p.clamped?'Yes':'—'}</td>
        <td>${p.disconnected?'Yes':'—'}</td>
        <td>${p.evacuated?'Yes':'—'}</td>
      </tr>`).join('')}
    </table>`;

  const logHtml = logEntries.length === 0 ? '<p><em>No activity recorded.</em></p>' : `
    <table>
      <tr><th>Time</th><th>Event</th></tr>
      ${logEntries.map(e=>`<tr><td>${new Date(e.at).toLocaleString()}</td><td>${e.message}</td></tr>`).join('')}
    </table>`;

  const win = window.open('', '_blank');
  win.document.write(`
    <html><head><title>Seismic Incident Report</title>
    <style>
      body{font-family:'IBM Plex Sans',Arial,sans-serif;max-width:760px;margin:32px auto;color:#0f1b1e;}
      h1{font-size:20px;border-bottom:3px solid #0f1b1e;padding-bottom:8px;}
      h2{font-size:14px;text-transform:uppercase;letter-spacing:.08em;margin-top:28px;color:#10484a;}
      h3{font-size:13px;margin-top:16px;}
      ul{padding-left:20px;font-size:13px;}
      li{margin-bottom:4px;}
      table{width:100%;border-collapse:collapse;font-size:12px;margin-top:8px;}
      th,td{border:1px solid #cdd9d8;padding:6px 8px;text-align:left;}
      th{background:#eef4f3;}
      .meta{font-size:12px;color:#5c7072;margin-bottom:20px;}
    </style></head>
    <body>
      <h1>Seismic Incident Report — SeismaDialysis</h1>
      <div class="meta">Generated ${new Date().toLocaleString()} · Event start ${startTime ? new Date(startTime).toLocaleString() : 'n/a'}</div>
      <h2>Protocol Checklist</h2>
      ${phaseHtml(steps1,'p1','Phase A — During Shaking')}
      ${phaseHtml(steps2,'p2','Phase B — Machine &amp; Line Management')}
      ${phaseHtml(steps3,'p3','Phase C — Facility &amp; Unit Check')}
      <h2>Patient Roster</h2>
      ${rosterHtml}
      <h2>Activity Log</h2>
      ${logHtml}
    </body></html>
  `);
  win.document.close();
  win.focus();
  win.print();
});

// ---- Boot: restore state if an event is already active ----
(async function boot(){
  try{
    const { event } = await api('/api/event/current');
    if(event){
      goActive(event.started_at);
      await loadChecklistState();
      await loadPatients();
      await loadLog();
    } else {
      renderRoster();
      renderLog();
    }
  }catch(err){
    console.error('Could not reach backend:', err.message);
    renderRoster();
    renderLog();
  }
})();
